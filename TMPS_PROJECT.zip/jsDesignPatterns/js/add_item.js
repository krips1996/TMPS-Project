var libsAndUtils = {
	"axios": {
		name: "Axios",
		version: "^0.18.0",
	},
	"@reach/router": {
		name: "Reach-Router",
		version: "^1.2.1",
	},
    "formik": {
    	name: "Formik",
    	version: "^1.5.1",
    },
    "glamor": {
    	name: "Formik",
    	version: "^2.20.40",
    },
    "node-sass": {
    	name: "Node-sass",
    	version: "^4.11.0",
    },
    "bit/georgeciubotaru.holdex.components.button": {
    	name: "Bit/button",
    	version: "0.0.30",
    },
    "bit/georgeciubotaru.holdex.components.click-outside": {
    	name: "Bit/click-outside",
    	version: "0.0.3",
    },
    "bit/georgeciubotaru.holdex.components.grid": {
    	name: "Bit/grid",
    	version: "0.0.25",
    },
    "bit/georgeciubotaru.holdex.components.modal": {
    	name: "Bit/modal",
    	version: "0.0.8",
    },
    "bit/georgeciubotaru.holdex.components.state": {
    	name: "Bit/state",
    	version: "0.0.3",
    },
}

var libAndUtilsAdded = {}

var selectedItem = {}

jQuery(function() {

	// constructor objects pattern
	function Item(name, type, description) {
		this.name = name;
		this.type = type;
		this.description = description;
	}


	var node = $("#myUL");

	for (var key in libsAndUtils) {
		node.append(
			`<li onclick="addSelectedItem('${key}')">
				<span>${libsAndUtils[key]["name"]}</span>
			</li>`
		)
	}

	$("#add-item-btn").on('click', function() {
		let item = new Object();
		let name = $('#name').val();
		if(!name) {
			alert('Put the value in name field');
			return null;
		}

		let type = $('input[type=radio][name=lib-type]:checked').val();
		if(!type) {
			alert('Select the type of library');
			return null;
		}

		let description = $('#lib-description').val();
		if(!description) {
			alert('Put the description value');
			return null;
		}

		item = new Item(name, type, description)
		libAndUtilsAdded = {...libAndUtilsAdded, ...selectedItem}

		$('#name').val('');
		$('#lib-description').val('');
		description = "";

		console.log('item ', item);

		AddItemModule.addItem(item);
		return null;
	});

	$("#generate").on('click', function() {
		if (Object.keys(libAndUtilsAdded).length === 0) {
			alert("You need to add libs or utils!")
		}

		var node = $("#json-packages")
		for(var key in libAndUtilsAdded) {
			node.append(`
				<li>
					"${key}": "${libAndUtilsAdded[key]["version"]}",
				</li>
			`)
		}
	})
});


//Module Pattern
const AddItemModule = (function() {
	let counter = 0,
		node = $('#libs > ul');

	function incrementCounter () {
		return counter++
	}

	function addItem(item) {
		node.append(
			`<li id="lib-elem-${counter}">
				<h3>
			 		${item.name} 
			 	</h3>
			 	<span>
			 		${item.type} 
			 	</span>
			 	<p> 
			 		${item.description} 
			 	</p>
				<span onclick="AddItemModule.deleteItem(${counter})">
					<svg xmlns="http://www.w3.org/2000/svg" width="18" height="16" viewBox="0 0 18 16">
					    <g fill="#223C54" fill-rule="nonzero">
					        <path d="M13.341 15.074L15.66 2.47H2.93l2.313 12.604h8.1zm.414.926H4.829a.484.484 0 0 1-.484-.384L1.861 2.086c-.052-.283.18-.542.484-.542h13.898c.305 0 .536.26.484.542l-2.489 13.53a.484.484 0 0 1-.483.384z"/>
					        <path d="M.69 2.822c-.262 0-.473-.2-.473-.446s.211-.446.472-.446h16.718c.26 0 .473.2.473.446s-.212.446-.473.446H.689z"/>
					        <path d="M11.316 0c.091 0 .18.033.246.092l1.948 1.717c.239.21.08.588-.246.588H5.08c-.326 0-.484-.377-.246-.587L6.777.092A.372.372 0 0 1 7.023 0h4.293zm-.142.68H7.166L5.99 1.717h6.362L11.174.679zM8.81 5.744c0-.188.162-.34.361-.34.199 0 .36.152.36.34v7.226c0 .187-.161.34-.36.34-.199 0-.36-.153-.36-.34V5.744zM12.227 5.702a.356.356 0 0 1 .402-.295.344.344 0 0 1 .312.379l-.957 7.226a.356.356 0 0 1-.402.295.344.344 0 0 1-.313-.38l.958-7.225zM5.54 5.786a.344.344 0 0 1 .312-.38.356.356 0 0 1 .402.296l.958 7.226a.344.344 0 0 1-.313.379.356.356 0 0 1-.402-.295L5.54 5.786z"/>
					        <path d="M9.063 2.283v13.353H4.896L2.375 2.283z" opacity=".3"/>
					    </g>
					</svg>
			 	</span>
			</li>`
		);
	}

	function fadeIn() {
		setTimeout(function() {
			$('#lib-elem-' + (counter - 1)).addClass('fade-in');
			clearTimeout();
		}, 100);
	}

	function fadeOut(i) {
		$('#lib-elem-' + i).removeClass('fade-in');
	}

	function deleteItem(i) {
		setTimeout(function() {
			$('#lib-elem-' + i).remove();
		}, 400)
	}


	return {
		addItem: function(item) {
			addItem(item)
			console.log('counter ' + counter)
			incrementCounter();
			fadeIn();
		},
		deleteItem: function(index) {
			fadeOut(index);
			deleteItem(index);
		},
	}
})();

//search function
function searchFunction() {
  // Declare variables
  var input, filter, ul, li, s, i, txtValue;
  input = document.getElementById('name');
  filter = input.value.toUpperCase();
  ul = document.getElementById("myUL");
  li = ul.getElementsByTagName('li');

  if(input && input.value.length === 0) {
  	ul.classList.add("hidden")
  } else {
  	if(ul.classList.contains("hidden")) {
  		ul.classList.remove("hidden")
  	}
  }

  // Loop through all list items, and hide those who don't match the search query
  for (i = 0; i < li.length; i++) {
    s = li[i].getElementsByTagName("span")[0];
    txtValue = s.textContent || s.innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "block";
    } else {
      li[i].style.display = "none";
    }
  }
}

//add selected item function
function addSelectedItem(key) {
	ul = document.getElementById("myUL");
	selectedItem[key] = libsAndUtils[key]
	$('#name').val(libsAndUtils[key]["name"])
	ul.classList.add("hidden")
	return null
}