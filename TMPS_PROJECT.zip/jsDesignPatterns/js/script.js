$(document).ready(function(){
    $('.slider').slick({
	    dots: true,
	    autoplay: true
    });
});